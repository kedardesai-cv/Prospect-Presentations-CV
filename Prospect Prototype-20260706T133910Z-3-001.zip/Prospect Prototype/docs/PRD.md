# CV Prospect Presentation Builder — PRD

**Version:** MVP 1.0 · **Date:** 2026-07-02 · **Owner:** Cecilia Storm
**Status:** Baseline defined, prototype split into modules
**Build model (decided 2026-07-02):** Option A — this app IS the MVP, not a disposable prototype. It is the official vertical slice; the 3-workstream team plan (docs/planning/) becomes the roadmap for this codebase. Workstream mapping: WS1 = intake/upload modules, WS2 = slide content/export modules, WS3 = topics/narrative modules. Pending team ratification of owners + schema sign-off date.
**Location:** C:\Users\Cecilia.Storm\Prospect Prototype (moved out of Prospect Data on 2026-07-02 -- product code lives separately from client data)

---

## 1. Why this exists

The single-file demo (`cv-prospect-builder-DEMO.html`, ~410KB / 4,447 lines) got too large to keep iterating on safely. This MVP restructures it into small files so development can continue fluidly, and strips the demo to its baseline: the minimum feature set that still runs the full end-to-end story.

## 1b. Project context (from Cecilia, 2026-07-02)

There are two compounding pains. **Slide creation itself is heavy** -- decks run up to 200 analysis slides and APMs work long hours out of office building them. And before a single slide can be made, **the data problem** has to be solved: statements, old presentations, asset research history, and analysis live in many different Excels and places, so the search-and-gather phase eats hours before the real work starts (e.g. checking whether an asset was ever researched before). The tool must attack both: automate slide production AND become the single home for the knowledge that feeds it -- past presentations, asset classifications and research history, per-PM client-base context, VIEWS/Bloomberg data -- with narratives suggested to PMs who keep full control. Pipeline order: data first, then brainstorming/story, then slides -- each stage's output feeds the next.

Corrections to earlier assumptions: the 20 intro slides are ALREADY automated (cv-intro-deck-builder skill) -- the only manual parts are pruning irrelevant slides and centering the org chart on the presenting PM team. Every PM team (Alan, Alex, Matthew, Ricardo) works differently: the tool must encode standard procedure PLUS per-PM quirks and client-base differences.

Hard dates and targets: **August 1, 2026 -- workable model that IT can build off, presented to Leadership.** Success target: 50-60% of the prospect presentation process handled by the prototype (stretch: 90%). Gabriel and Jose are PMs (no fixed acceptance criteria yet). Compliance is headed by Beatrice -- interview her as the model matures. Integration: VIEWS (Bloomberg-connected) for now, but VIEWS is being phased out -- keep the parser format-agnostic behind the schema. Biggest named risk: **AI bias / AI-assumed numbers not accurate to the data** -- PMs must never be swayed by an incorrect narrative; this is why the deterministic-figures rule exists.

## 2. What the tool does (end-to-end spine)

A CV Advisors PM preps a prospect presentation in five stages:

1. **Stage 0 — Intake.** Client code, meeting date, PM profile, free-text client brain dump. Keyword parsing generates intake cards.
2. **Stage 1 — Upload.** Drag-and-drop the accounting Excel; the file is parsed into holdings rows.
3. **Stage 2 — Analysis.** Portfolio issues surface as selectable topic pills backed by data tiles (cash drag, concentration, fees, allocation, CV comparisons, IPS, next steps).
4. **Stage 3 — Blueprint.** Selected topics map to slide components; the PM assembles the deck outline.
5. **Stage 4 — Deck.** Slide filmstrip with full slide previews; export the deck. **PowerPoint (.pptx) export is a baseline must-have** (matches team plan M-05 — PMs work in PPTX, an editable deck is the actual deliverable). HTML export and copyable outline remain as interim/secondary formats until the PPTX exporter is built.

This spine is the **baseline** — it must always work, offline, by double-clicking `index.html`. No server, no API key, no network.

## 3. Baseline vs nice-to-have (decision record, 2026-07-02)

Decision: the baseline is the full end-to-end process, made as lean as possible. The following were excised from the baseline and preserved as flag-gated modules.

| Area | Excised from baseline (nice-to-have) |
|---|---|
| Intake/Upload | AI intake analysis (keyword parsing stays), missed-info additions, transcript upload, self-directed account panel, manual asset classification, statement-source + missing-position detection* |
| Analysis | AI thinking animation, ask-AI-opinion, follow-up Q&A, narrative generation/toggle, client-specific topic pills (BlackRock M&A, North Haven, ACI, B&N) |
| Blueprint/Deck | Custom components, custom charts + live preview, custom slides, per-slide AI regeneration, slide reorder, print (HTML export stays) |
| AI | Live Claude API calls. **Mocked by default** — canned responses so the demo can never break in a meeting. Entering an API key re-enables live calls. |

Numbers rule (revised 2026-07-02, supersedes the team plan's "humans compute, AI presents"): **every client-facing figure is computed deterministically — by code, from validated data — and must trace back to the source payload. The AI never invents or estimates a figure in generated text; it only presents computed values.** Accuracy comes from computation over validated data, not from restricting who computes. Flag for team review: this rewords a hard rule in docs/planning/project-manifest.json, so the workstream owners should sign off.

Slide reorder stays excised from the baseline even though the team plan ranks it "should" (reaffirmed 2026-07-02).

\* Detection code still runs internally in MVP 1.0 (harmless, no UI impact); flagged for removal in the excision pass.

## 4. How the gating works

Every excised feature is controlled by a flag in `dev/js/00-config.js` (`window.FEATURES`). `dev/js/99-baseline-gate.js` loads last and hides the UI + disables the functions for anything switched off. **Re-enabling a module = flipping one flag to `true`.** Code was not deleted in this pass — a hard code-removal ("excision") pass happens after the baseline is validated in real use, so we never break the demo while cutting.

## 5. File structure

```
Prospect Prototype/
├── docs/
│   ├── PRD.md                  ← this file
│   ├── prototype/              ← frozen single-file prototypes (reference only)
│   └── feedback/               ← one file per brainstorm/meeting, dated YYYY-MM-DD_topic
└── dev/                        ← active development (open index.html to run)
    ├── index.html              ← markup only, loads css + js in order
    ├── css/styles.css
    └── js/
        ├── 00-config.js        ← FEATURE FLAGS (edit here)
        ├── 01-ai.js            ← API key mgmt + callClaude + safeStore
        ├── 02-panels-state.js  ← resizable panels, app state, intake cards, stage nav
        ├── 03-slide-lib.js     ← slide + topic-slide libraries (data)
        ├── 04-stage2-blueprint.js
        ├── 05-analysis.js      ← portfolio context + AI analysis
        ├── 06-stage4-deck.js   ← filmstrip, edit panel
        ├── 07-slide-content.js ← full slide content builders (largest file)
        ├── 08-custom-components.js  [nice-to-have]
        ├── 09-export.js        ← HTML export, outline, print
        ├── 10-intake-upload.js ← drop zones, xlsx parsing, intake analysis
        ├── 11-topics-tiles.js  ← topic pills + data tiles
        ├── 12-detection.js     [nice-to-have]
        ├── 13-self-directed.js [nice-to-have]
        ├── 14-init.js          ← demo pre-fill (FRIO-RIVER)
        ├── 15-custom-charts.js [nice-to-have]
        └── 99-baseline-gate.js ← applies flags; loads LAST
```

Constraints: plain `<script>` tags in fixed order (no ES modules, no fetch of local files) so it works from `file://`. New scripts go between `00` and `99`. Never load anything after `99-baseline-gate.js`.

## 6. Working agreement

- `docs/prototype/` is frozen — never edit, reference only.
- After every brainstorm, drop notes into `docs/feedback/` as `YYYY-MM-DD_topic.ext`.
- All development happens in `dev/`. Keep each file under ~500 lines; split when it grows past that.
- `07-slide-content.js` (~1,000 lines) is the next candidate to split (per-topic content files).
- Update this PRD when a flag graduates into the baseline or a module is hard-removed.

## 7. Open items

- [ ] Validate the baseline in a real run-through (all four teams' flows)
- [ ] Excision pass: hard-remove disabled code paths once baseline is validated
- [ ] Split `07-slide-content.js` by topic
- [ ] Replace CDN-hosted CV logo with a local asset (currently needs network to render the logo)
- [ ] Decide whether statement-source/missing-position detection returns to baseline or is removed

Adopted from team plan (docs/planning/, 2026-07-02):

- [ ] Adopt `validated_portfolio.json` schema (docs/planning/shared-data-schema.json) as the parser output contract in `10-intake-upload.js`
- [ ] Add human validation gate between Stage 1 and Stage 2 — no data reaches a slide unvalidated; stamp `validated_by`/`validated_at`
- [ ] Add SEC Marketing Rule flagging pass before export (maps to cv-sec-marketing-review criteria)
- [ ] **Build the PPTX exporter (MUST-HAVE, promoted 2026-07-02)** — the demo only exports HTML today; the baseline is not complete until decks export as .pptx
- [ ] Obtain missing workstream-2-deck-generation.json (WS2 tasks) from coworker

From project context (2026-07-02):

- [ ] Design the prospect data file so it grows into the knowledge base (asset research history, classification records, per-PM/team profiles) -- not just a single-deck payload
- [ ] Per-PM/team profiles: standard procedure + team quirks (PM_PROFILES already exists in the demo -- elevate it)
- [ ] Intro section: integrate the existing cv-intro-deck-builder output; add slide pruning + org-chart-centered-on-team as the only manual steps
- [ ] Figure provenance: every number on a slide traceable/linkable to its source field (counters the AI-bias risk)
- [ ] Define the process-step checklist that the 50-60% (stretch 90%) coverage target is measured against
- [ ] Interview Beatrice (compliance) for guideline requirements; future: push-to-compliance and push-to-research routing (e.g. unclassified asset, ETF not analyzed in 2 quarters)
- [ ] Deadline: Aug 1 -- deliverable is a workable model IT CAN BUILD OFF: clean modules, locked schema, docs. Handoff quality = a feature.

From Alan team feedback (2026-07-02, see docs/feedback/):

- [ ] Extend issue flagging to third-party managed (SMA) accounts, incl. high-fee flag (routing "SSR" TBD)
- [ ] "Another family office involved" alert for the PM
- [ ] Accept fee-analysis Excel as a direct upload (not only CV app export); fee analysis draws on full Ops folder (managed, brokerage, loan)
- [ ] Statement (PDF) parsing: parked -- rejected by Alan team so far
- [ ] Multi-statement / multi-portfolio prospects
- [ ] "Mark as final" lifecycle: post-compliance completion -> files deck into database -> newest deck becomes AI training/knowledge-base material (closes the knowledge loop)
